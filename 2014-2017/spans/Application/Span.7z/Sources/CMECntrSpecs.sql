use [spans];
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OofSpecsVenue]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[OofSpecsVenue];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FwdSpecsVenue]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[FwdSpecsVenue];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FutSpecsVenue]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[FutSpecsVenue];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OofSpecs]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[OofSpecs];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FwdSpecs]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[FwdSpecs];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FutSpecs]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[FutSpecs];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OofPf]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[OofPf];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FwdPf]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[FwdPf];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FutPf]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[FutPf];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Exchange]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[Exchange];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Venue]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[Venue];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ClearingOrg]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[ClearingOrg];
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[_created]') AND type in (N'U')) 
BEGIN 
CREATE TABLE [dbo].[_created](
	[spanFile] [nvarchar](50) NULL,
	[marginRatesFile] [nvarchar](50) NULL,
	[productCalendarFile] [nvarchar](50) NULL,
	[lastUpdated] [datetime] default GETDATE() NOT NULL
) ON [PRIMARY]
END
GO

CREATE TABLE [dbo].[OofSpecsVenue] ( 
[VenueId] [int] NOT NULL,
[OofSpecsId] [int] NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_OofSpecsVenue] PRIMARY KEY CLUSTERED ([VenueId] ASC, [OofSpecsId] ASC))
GO


CREATE TABLE [dbo].[FwdSpecsVenue] ( 
[VenueId] [int] NOT NULL,
[FwdSpecsId] [int] NOT NULL
, CONSTRAINT [PK_FwdSpecsVenue] PRIMARY KEY CLUSTERED ([VenueId] ASC, [FwdSpecsId] ASC))
GO


CREATE TABLE [dbo].[FutSpecsVenue] ( 
[VenueId] [int] NOT NULL,
[FutSpecsId] [int] NOT NULL
, CONSTRAINT [PK_FutSpecsVenue] PRIMARY KEY CLUSTERED ([VenueId] ASC, [FutSpecsId] ASC))
GO


CREATE TABLE [dbo].[OofSpecs] ( 
[Id] [int] identity(1, 1) NOT NULL,
[OofPfId] [int] NOT NULL,
[aliasDesc] [nvarchar] (1024) NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_OofSpecs] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[FwdSpecs] ( 
[Id] [int] identity(1, 1) NOT NULL,
[FwdPfId] [int] NOT NULL,
[aliasDesc] [nvarchar] (1024) NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_FwdSpecs] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[FutSpecs] ( 
[Id] [int] identity(1, 1) NOT NULL,
[FutPfId] [int] NOT NULL,
[aliasDesc] [nvarchar] (1024) NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_FutSpecs] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[OofPf] ( 
[Id] [int] identity(1, 1) NOT NULL,
[ExchangeId] [int] NOT NULL,
[status] [nvarchar] (1024) NOT NULL,
[rptOrder] [nvarchar] (1024) NOT NULL,
[pageBreak] [nvarchar] (1024) NOT NULL,
[pfCode] [nvarchar] (1024) NOT NULL,
[name] [nvarchar] (1024) NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_OofPf] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[FwdPf] ( 
[Id] [int] identity(1, 1) NOT NULL,
[ExchangeId] [int] NOT NULL,
[status] [nvarchar] (1024) NOT NULL,
[rptOrder] [nvarchar] (1024) NOT NULL,
[pageBreak] [nvarchar] (1024) NOT NULL,
[pfCode] [nvarchar] (1024) NOT NULL,
[name] [nvarchar] (1024) NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_FwdPf] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[FutPf] ( 
[Id] [int] identity(1, 1) NOT NULL,
[ExchangeId] [int] NOT NULL,
[status] [nvarchar] (1024) NOT NULL,
[rptOrder] [nvarchar] (1024) NOT NULL,
[pageBreak] [nvarchar] (1024) NOT NULL,
[pfCode] [nvarchar] (1024) NOT NULL,
[name] [nvarchar] (1024) NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_FutPf] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[Exchange] ( 
[Id] [int] identity(1, 1) NOT NULL,
[ClearingOrgId] [int] NOT NULL,
[exch] [nvarchar] (1024) NOT NULL,
[exchAlias] [nvarchar] (1024) NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_Exchange] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[Venue] ( 
[Id] [int] NOT NULL,
[name] [nvarchar] (1024) NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_Venue] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[ClearingOrg] ( 
[Id] [int] identity(1, 1) NOT NULL,
[ec] [nvarchar] (1024) NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_ClearingOrg] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


ALTER TABLE [dbo].[Exchange] WITH CHECK ADD CONSTRAINT [FK_ClearingOrg_Exchange] FOREIGN KEY([ClearingOrgId]) 
REFERENCES [dbo].[ClearingOrg] ([Id]) 
GO
ALTER TABLE [dbo].[FutPf] WITH CHECK ADD CONSTRAINT [FK_Exchange_FutPf] FOREIGN KEY([ExchangeId]) 
REFERENCES [dbo].[Exchange] ([Id]) 
GO
ALTER TABLE [dbo].[FutSpecs] WITH CHECK ADD CONSTRAINT [FK_FutPf_FutSpecs] FOREIGN KEY([FutPfId]) 
REFERENCES [dbo].[FutPf] ([Id]) 
GO
ALTER TABLE [dbo].[FwdPf] WITH CHECK ADD CONSTRAINT [FK_Exchange_FwdPf] FOREIGN KEY([ExchangeId]) 
REFERENCES [dbo].[Exchange] ([Id]) 
GO
ALTER TABLE [dbo].[FwdSpecs] WITH CHECK ADD CONSTRAINT [FK_FwdPf_FwdSpecs] FOREIGN KEY([FwdPfId]) 
REFERENCES [dbo].[FwdPf] ([Id]) 
GO
ALTER TABLE [dbo].[OofPf] WITH CHECK ADD CONSTRAINT [FK_Exchange_OofPf] FOREIGN KEY([ExchangeId]) 
REFERENCES [dbo].[Exchange] ([Id]) 
GO
ALTER TABLE [dbo].[OofSpecs] WITH CHECK ADD CONSTRAINT [FK_OofPf_OofSpecs] FOREIGN KEY([OofPfId]) 
REFERENCES [dbo].[OofPf] ([Id]) 
GO
ALTER TABLE [dbo].[FutSpecsVenue] WITH CHECK ADD CONSTRAINT [FK_FutSpecs_FutSpecsVenue] FOREIGN KEY([FutSpecsId]) 
REFERENCES [dbo].[FutSpecs] ([Id]) 
GO
ALTER TABLE [dbo].[FwdSpecsVenue] WITH CHECK ADD CONSTRAINT [FK_FwdSpecs_FwdSpecsVenue] FOREIGN KEY([FwdSpecsId]) 
REFERENCES [dbo].[FwdSpecs] ([Id]) 
GO
ALTER TABLE [dbo].[OofSpecsVenue] WITH CHECK ADD CONSTRAINT [FK_OofSpecs_OofSpecsVenue] FOREIGN KEY([OofSpecsId]) 
REFERENCES [dbo].[OofSpecs] ([Id]) 
GO


 -- !!!!!!!!!!!!!! Run this script manually for the Spans database.