use [spans];
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PointDefScanPoint]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[PointDefScanPoint];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PointDefDeltaPoint]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[PointDefDeltaPoint];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BFPFLinkageMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[BFPFLinkageMaster];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[XMAMasterRounding]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[XMAMasterRounding];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ClearingOrgMasterRounding]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[ClearingOrgMasterRounding];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProductFamilyMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[ProductFamilyMaster];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PointDef]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[PointDef];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BFExchLinkageMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[BFExchLinkageMaster];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BFCOLinkageMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[BFCOLinkageMaster];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ExchangeMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[ExchangeMaster];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeltaPoint]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[DeltaPoint];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScanPoint]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[ScanPoint];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rounding]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[Rounding];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AccountTypeMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[AccountTypeMaster];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SegTypeMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[SegTypeMaster];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CurrencyMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[CurrencyMaster];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PBClassDefMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[PBClassDefMaster];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ClearingOrgMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[ClearingOrgMaster];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[XMAMaster]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[XMAMaster];
END
GO

CREATE TABLE [dbo].[PointDefScanPoint] ( 
[PointDefId] [int] NULL,
[ScanPointId] [nvarchar] (32) NULL
--, CONSTRAINT [PK_PointDefScanPoint] PRIMARY KEY CLUSTERED ([PointDefId] ASC, [ScanPointId] ASC)
)
GO


CREATE TABLE [dbo].[PointDefDeltaPoint] ( 
[PointDefId] [int] NULL,
[DeltaPointId] [nvarchar] (32) NULL
--, CONSTRAINT [PK_PointDefDeltaPoint] PRIMARY KEY CLUSTERED ([PointDefId] ASC, [DeltaPointId] ASC)
)
GO


CREATE TABLE [dbo].[BFPFLinkageMaster] ( 
[Id] [int] identity(1, 1) NOT NULL,
[BFExchLinkageMasterId] [int] NOT NULL,
[PFCode] [nvarchar] (1024) NULL,
[Type] [tinyint] NOT NULL,
[PFCodeAlias] [nvarchar] (1024) NULL,
[SettleDecLoc] [tinyint] NOT NULL,
[StrikeDecLoc] [nvarchar] (1024) NULL,
[SettleAlignCode] [nvarchar] (1024) NULL,
[StrikeAlignCode] [nvarchar] (1024) NULL,
[CabinetOptionValue] [numeric] (18, 6) NOT NULL,
[SkipOnLoad] [tinyint] NOT NULL,
[CurrentlyActive] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_BFPFLinkageMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[XMAMasterRounding] ( 
[RoundingId] [nvarchar] (32) NOT NULL,
[XMAMasterId] [int] NOT NULL
, CONSTRAINT [PK_XMAMasterRounding] PRIMARY KEY CLUSTERED ([RoundingId] ASC, [XMAMasterId] ASC))
GO


CREATE TABLE [dbo].[ClearingOrgMasterRounding] ( 
[RoundingId] [nvarchar] (32) NOT NULL,
[ClearingOrgMasterId] [int] NOT NULL
, CONSTRAINT [PK_ClearingOrgMasterRounding] PRIMARY KEY CLUSTERED ([RoundingId] ASC, [ClearingOrgMasterId] ASC))
GO


CREATE TABLE [dbo].[ProductFamilyMaster] ( 
[Id] [int] identity(1, 1) NOT NULL,
[ExchangeMasterId] [int] NOT NULL,
[PFCode] [nvarchar] (1024) NULL,
[Type] [tinyint] NOT NULL,
[PFName] [nvarchar] (1024) NULL,
[CVM] [numeric] (18, 6) NOT NULL,
[SettleDecLoc] [tinyint] NOT NULL,
[StrikeDecLoc] [nvarchar] (1024) NULL,
[SettleAlignCode] [nvarchar] (1024) NULL,
[StrikeAlignCode] [nvarchar] (1024) NULL,
[CabinetOptionValue] [numeric] (18, 6) NOT NULL,
[SkipOnLoad] [tinyint] NOT NULL,
[CurrentlyActive] [nvarchar] (1024) NULL,
[PricingModel] [nvarchar] (1024) NULL,
[PriceQuotationMethod] [nvarchar] (1024) NULL,
[ValuationMethod] [nvarchar] (1024) NULL,
[SettlementMethod] [nvarchar] (1024) NULL,
[SettleCurrencyCode] [nvarchar] (1024) NULL,
[CountryCode] [nvarchar] (1024) NULL,
[ExerciseStyle] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_ProductFamilyMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[PointDef] ( 
[id] [int] identity(1, 1) NOT NULL,
[XMAMasterId] [int] NULL,
[ClearingOrgMasterId] [int] NULL,
[PBClassID] [tinyint] NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_PointDef] PRIMARY KEY CLUSTERED ([id] ASC))
GO


CREATE TABLE [dbo].[BFExchLinkageMaster] ( 
[Id] [int] identity(1, 1) NOT NULL,
[BFCOLinkageMasterId] [int] NOT NULL,
[ExchAcro] [nvarchar] (1024) NULL,
[ExchAcroAlias] [nvarchar] (1024) NULL,
[ExchCodeAlias] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_BFExchLinkageMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[BFCOLinkageMaster] ( 
[Id] [int] identity(1, 1) NOT NULL,
[XMAMasterId] [int] NOT NULL,
[COAcro] [nvarchar] (1024) NULL,
[COAcroAlias] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_BFCOLinkageMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[ExchangeMaster] ( 
[ClearingOrgMasterId] [int] NOT NULL,
[Id] [int] identity(1, 1) NOT NULL,
[ExchAcro] [nvarchar] (1024) NULL,
[ExchCode] [nvarchar] (1024) NULL,
[ExchName] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_ExchangeMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[DeltaPoint] ( 
[Id] [nvarchar] (32) NULL,
[PointNumber] [tinyint] NOT NULL,
[PriceScanMult] [numeric] (18, 6) NOT NULL,
[PriceScanNumerator] [numeric] (18, 6) NOT NULL,
[PriceScanDenominator] [numeric] (18, 6) NOT NULL,
[VolScanMult] [numeric] (18, 6) NOT NULL,
[VolScanNumerator] [numeric] (18, 6) NOT NULL,
[VolScanDenominator] [numeric] (18, 6) NOT NULL,
[DeltaProbWeight] [numeric] (18, 6) NOT NULL,
[MissingElements] [xml] NULL
--, CONSTRAINT [PK_DeltaPoint] PRIMARY KEY CLUSTERED ([Id] ASC)
)
GO


CREATE TABLE [dbo].[ScanPoint] ( 
[Id] [nvarchar] (32) NULL,
[PointNumber] [tinyint] NOT NULL,
[PriceScanMult] [numeric] (18, 6) NOT NULL,
[PriceScanNumerator] [numeric] (18, 6) NOT NULL,
[PriceScanDenominator] [numeric] (18, 6) NOT NULL,
[VolScanMult] [numeric] (18, 6) NOT NULL,
[VolScanNumerator] [numeric] (18, 6) NOT NULL,
[VolScanDenominator] [numeric] (18, 6) NOT NULL,
[DeltaProbWeight] [numeric] (18, 6) NOT NULL,
[PairedPointNumber] [tinyint] NOT NULL,
[MissingElements] [xml] NULL
--, CONSTRAINT [PK_ScanPoint] PRIMARY KEY CLUSTERED ([Id] ASC)
)
GO


CREATE TABLE [dbo].[Rounding] ( 
[Id] [nvarchar] (32) NULL,
[RoundingPlace] [tinyint] NOT NULL,
[RoundingType] [tinyint] NOT NULL,
[DecimalDigits] [tinyint] NOT NULL,
[MissingElements] [xml] NULL
--, CONSTRAINT [PK_Rounding] PRIMARY KEY CLUSTERED ([Id] ASC)
)
GO


CREATE TABLE [dbo].[AccountTypeMaster] ( 
[Id] [int] identity(1, 1) NOT NULL,
[AcctTypeCode] [nvarchar] (1024) NULL,
[AcctTypeDesc] [nvarchar] (1024) NULL,
[IsClearingLevel] [tinyint] NOT NULL,
[IsGrossMargin] [tinyint] NOT NULL,
[Priority] [tinyint] NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_AccountTypeMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[SegTypeMaster] ( 
[Id] [int] identity(1, 1) NOT NULL,
[SegTypeCode] [nvarchar] (1024) NULL,
[SegTypeDesc] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_SegTypeMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[CurrencyMaster] ( 
[Id] [int] identity(1, 1) NOT NULL,
[CurrencyCode] [nvarchar] (1024) NULL,
[CurrencySymbol] [nvarchar] (1024) NULL,
[CurrencyName] [nvarchar] (1024) NULL,
[DecPos] [tinyint] NOT NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_CurrencyMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[PBClassDefMaster] ( 
[Id] [int] identity(1, 1) NOT NULL,
[PBClassID] [tinyint] NOT NULL,
[PBClassCode] [nvarchar] (1024) NULL,
[PBClassDesc] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_PBClassDefMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[ClearingOrgMaster] ( 
[Id] [int] identity(1, 1) NOT NULL,
[COAcro] [nvarchar] (1024) NULL,
[COName] [nvarchar] (1024) NULL,
[COAcroAlias] [nvarchar] (1024) NULL,
[IsGrossMargin] [tinyint] NOT NULL,
[DoContractScaling] [tinyint] NOT NULL,
[DoIntercommSpreading] [tinyint] NOT NULL,
[LoadDeltaScalingFactors] [tinyint] NOT NULL,
[LoadRedefRecords] [tinyint] NOT NULL,
[LimitOptionValue] [tinyint] NOT NULL,
[AggregateByPosType] [tinyint] NOT NULL,
[SOMGross] [tinyint] NOT NULL,
[PrefixCCNames] [tinyint] NOT NULL,
[LoadScanSpreads] [tinyint] NOT NULL,
[CustUseLov] [tinyint] NOT NULL,
[UseLovPct] [numeric] (18, 6) NOT NULL,
[LimitSubAccountOffset] [tinyint] NOT NULL,
[DefaultWFPRMeth] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_ClearingOrgMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[XMAMaster] ( 
[Id] [int] identity(1, 1) NOT NULL,
[COAcro] [nvarchar] (1024) NULL,
[COName] [nvarchar] (1024) NULL,
[COAcroAlias] [nvarchar] (1024) NULL,
[IsGrossMargin] [tinyint] NOT NULL,
[DoContractScaling] [tinyint] NOT NULL,
[DoIntercommSpreading] [tinyint] NOT NULL,
[LoadDeltaScalingFactors] [tinyint] NOT NULL,
[LoadRedefRecords] [tinyint] NOT NULL,
[LimitOptionValue] [tinyint] NOT NULL,
[AggregateByPosType] [tinyint] NOT NULL,
[SOMGross] [tinyint] NOT NULL,
[PrefixCCNames] [tinyint] NOT NULL,
[LoadScanSpreads] [tinyint] NOT NULL,
[CustUseLov] [tinyint] NOT NULL,
[UseLovPct] [numeric] (18, 6) NOT NULL,
[LimitSubAccountOffset] [tinyint] NOT NULL,
[DefaultWFPRMeth] [nvarchar] (1024) NULL,
[BusFuncType] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_XMAMaster] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


ALTER TABLE [dbo].[ProductFamilyMaster] WITH CHECK ADD CONSTRAINT [FK_ExchangeMaster_ProductFamilyMaster] FOREIGN KEY([ExchangeMasterId]) 
REFERENCES [dbo].[ExchangeMaster] ([Id]) 
GO
ALTER TABLE [dbo].[ExchangeMaster] WITH CHECK ADD CONSTRAINT [FK_ClearingOrgMaster_ExchangeMaster] FOREIGN KEY([ClearingOrgMasterId]) 
REFERENCES [dbo].[ClearingOrgMaster] ([Id]) 
GO
ALTER TABLE [dbo].[PointDef] WITH CHECK ADD CONSTRAINT [FK_ClearingOrgMaster_PointDef] FOREIGN KEY([ClearingOrgMasterId]) 
REFERENCES [dbo].[ClearingOrgMaster] ([Id]) 
GO
ALTER TABLE [dbo].[ClearingOrgMasterRounding] WITH CHECK ADD CONSTRAINT [FK_ClearingOrgMaster_ClearingOrgMasterRounding] FOREIGN KEY([ClearingOrgMasterId]) 
REFERENCES [dbo].[ClearingOrgMaster] ([Id]) 
GO
ALTER TABLE [dbo].[XMAMasterRounding] WITH CHECK ADD CONSTRAINT [FK_XMAMaster_XMAMasterRounding] FOREIGN KEY([XMAMasterId]) 
REFERENCES [dbo].[XMAMaster] ([Id]) 
GO
ALTER TABLE [dbo].[PointDef] WITH CHECK ADD CONSTRAINT [FK_XMAMaster_PointDef] FOREIGN KEY([XMAMasterId]) 
REFERENCES [dbo].[XMAMaster] ([Id]) 
GO
ALTER TABLE [dbo].[BFCOLinkageMaster] WITH CHECK ADD CONSTRAINT [FK_XMAMaster_BFCOLinkageMaster] FOREIGN KEY([XMAMasterId]) 
REFERENCES [dbo].[XMAMaster] ([Id]) 
GO
ALTER TABLE [dbo].[BFExchLinkageMaster] WITH CHECK ADD CONSTRAINT [FK_BFCOLinkageMaster_BFExchLinkageMaster] FOREIGN KEY([BFCOLinkageMasterId]) 
REFERENCES [dbo].[BFCOLinkageMaster] ([Id]) 
GO
ALTER TABLE [dbo].[BFPFLinkageMaster] WITH CHECK ADD CONSTRAINT [FK_BFExchLinkageMaster_BFPFLinkageMaster] FOREIGN KEY([BFExchLinkageMasterId]) 
REFERENCES [dbo].[BFExchLinkageMaster] ([Id]) 
GO
ALTER TABLE [dbo].[PointDefDeltaPoint] WITH CHECK ADD CONSTRAINT [FK_PointDef_PointDefDeltaPoint] FOREIGN KEY([PointDefId]) 
REFERENCES [dbo].[PointDef] ([id]) 
GO
ALTER TABLE [dbo].[PointDefScanPoint] WITH CHECK ADD CONSTRAINT [FK_PointDef_PointDefScanPoint] FOREIGN KEY([PointDefId]) 
REFERENCES [dbo].[PointDef] ([id]) 
GO


 -- !!!!!!!!!!!!!! Run this script manually for the Spans database.