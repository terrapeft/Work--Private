use [spans];
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tier]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[Tier];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TierProduct]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[TierProduct];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rates]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[Rates];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MarginProduct]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[MarginProduct];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BFCC]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[BFCC];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tiers]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[Tiers];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[VolSomRates]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[VolSomRates];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProductFamily]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[ProductFamily];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Groups]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[Groups];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BFCCProductFamily]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[BFCCProductFamily];
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MarginProductProductFamily]') AND type in (N'U')) 
BEGIN 
DROP TABLE [dbo].[MarginProductProductFamily];
END
GO


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[_created]') AND type in (N'U')) 
BEGIN 
CREATE TABLE [dbo].[_created](
	[spanFile] [nvarchar](50) NULL,
	[marginRatesFile] [nvarchar](50) NULL,
	[productCalendarFile] [nvarchar](50) NULL,
	[lastUpdated] [datetime] default GETDATE() NOT NULL,
	[MissingElements] [xml] NULL	
) ON [PRIMARY]
END
GO

CREATE TABLE [dbo].[Tier] ( 
[Id] [int] identity(1, 1) NOT NULL,
[TierProductId] [int] NULL,
[TierSeqNumber] [tinyint] NULL,
[StartTierPeriodType] [nvarchar] (1024) NULL,
[StartPeriodSeq] [nvarchar] (1024) NULL,
[EndTierPeriodType] [nvarchar] (1024) NULL,
[EndPeriodSeq] [nvarchar] (1024) NULL,
[Effetive] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_Tier] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[TierProduct] ( 
[Id] [int] identity(1, 1) NOT NULL,
[TierId] [int] NULL,
[IsCurrent] [tinyint] NULL,
[TierProductDescription] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_TierProduct] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[MarginProduct] ( 
[Id] [int] identity(1, 1) NOT NULL,
[GroupId] [int] NULL,
[IsCurrent] [bit] NULL,
[Outright] [bit] NULL,
[IntraCommodity] [bit] NULL,
[InterCommodity] [bit] NULL,
[Intex] [bit] NULL,
[ProductDescription] [nvarchar] (1024) NULL,
[BFCC_ID] [int] NULL,
[CCCode] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_MarginProduct] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[Rates] ( 
[Id] [int] identity(1, 1) NOT NULL,
[MarginProductId] [int] NULL,
[RateType] [nvarchar] (1024) NULL,
[Ratio] [nvarchar] (1024) NULL,
[isPercentage] [bit] NULL,
[ISOCode] [nvarchar] (1024) NULL,
[Symbol] [nvarchar] (1024) NULL,
[InitialRequirement] [numeric] (18, 6) NULL,
[MaintenanceRequirement] [numeric] (18, 6) NULL,
[Effective] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_Rates] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[BFCC] ( 
[Id] [int] identity(1, 1) NOT NULL,
[CCCode] [nvarchar] (1024) NULL,
[CCName] [nvarchar] (1024) NULL,
[Effective] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_BFCC] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[Tiers] ( 
[Id] [int] identity(1, 1) NOT NULL,
[TierTypeDescription] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_Tiers] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[VolSomRates] ( 
[Id] [int] identity(1, 1) NOT NULL,
[Ticker] [nvarchar] (1024) NULL,
[ProductName] [nvarchar] (1024) NULL,
[isPctM] [bit] NULL,
[MaintToInit] [nvarchar] (1024) NULL,
[isPctV] [bit] NULL,
[VolScan] [nvarchar] (1024) NULL,
[isPctS] [bit] NULL,
[SOM] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_VolSomRates] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[ProductFamily] ( 
[Id] [nvarchar] (32) NOT NULL,
[PFCode] [nvarchar] (1024) NULL,
[Long_Name] [nvarchar] (1024) NULL,
[ScalingFactor] [numeric] (18, 6) NULL,
[PFType] [nvarchar] (1024) NULL,
[C21Type] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_ProductFamily] PRIMARY KEY CLUSTERED ([Id] ASC))
GO


CREATE TABLE [dbo].[Groups] ( 
[Id] [int] identity(1, 1) NOT NULL,
[GroupDescription] [nvarchar] (1024) NULL,
[MissingElements] [xml] NULL
, CONSTRAINT [PK_Groups] PRIMARY KEY CLUSTERED ([Id] ASC))
GO

CREATE TABLE [dbo].[BFCCProductFamily] ( 
[ProductFamilyId] [nvarchar] (32) NOT NULL,
[BFCCID] [int] NOT NULL
, CONSTRAINT [PK_BFCCProductFamily] PRIMARY KEY CLUSTERED ([ProductFamilyId] ASC, [BFCCID] ASC))
GO

CREATE TABLE [dbo].[MarginProductProductFamily] ( 
[ProductFamilyId] [nvarchar] (32) NOT NULL,
[MarginProductId] [int] NOT NULL
, CONSTRAINT [PK_MarginProductProductFamily] PRIMARY KEY CLUSTERED ([ProductFamilyId] ASC, [MarginProductId] ASC))
GO


ALTER TABLE [dbo].[MarginProduct] WITH CHECK ADD CONSTRAINT [FK_Group_MarginProduct] FOREIGN KEY([GroupId]) 
REFERENCES [dbo].[Groups] ([Id]) 
GO

ALTER TABLE [dbo].[Rates] WITH CHECK ADD CONSTRAINT [FK_MarginProduct_Rates] FOREIGN KEY([MarginProductId]) 
REFERENCES [dbo].[MarginProduct] ([Id]) 
GO

ALTER TABLE [dbo].[TierProduct] WITH CHECK ADD CONSTRAINT [FK_Tiers_TierProduct] FOREIGN KEY([TierId]) 
REFERENCES [dbo].[Tiers] ([Id]) 
GO

ALTER TABLE [dbo].[Tier] WITH CHECK ADD CONSTRAINT [FK_TierProduct_Tier] FOREIGN KEY([TierProductId]) 
REFERENCES [dbo].[TierProduct] ([Id]) 
GO


 -- !!!!!!!!!!!!!! Run this script manually for the Spans database.